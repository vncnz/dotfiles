from datetime import datetime

from ignis.widgets import Widget
from ResBox import ResIcon
from Bus import Bus

from gi.repository import Gtk

from theme_colors import col, gra

class TimeLine (Widget.Window):
    def __init__(self, monitor = None):

        self.h = 750

        self.line_now = Widget.Label(
            label = '',
            justify='left',
            style = 'font-size: 1.5em;color:red;',
            xalign= 1.0
        )

        self.box2 = Gtk.Fixed(width_request=6, height_request=self.h)

        self.battery_end = Widget.Label(
            label="",
            width_request=2,
            height_request=1
        )
        self.box2.put(self.battery_end, 0, 0)

        self.hours = []
        for h in range(0,25,1):
            if h % 6 == 0: size, color = '1.5rem', col('primary')
            elif h % 3 == 0: size, color = '1.2rem', 'white'
            else: size, color = '1rem', 'gray'
            # m = (self.h / 12) * (h - 12)
            dict = {
                'label': '󰍞',
                'justify': 'left',
                'style': f'font-size:{size};color:{color};',
                'xalign': 1.0,
                'width_request': 10
            }
            label = Widget.Label(**dict)
            m = (self.h / 24) * h
            # m = self.vadjust(label, m)
            self.box2.put(label, 50, m)
            self.hours.append(label)


        self.box2.put(self.line_now, 0, self.h / 2)

        super().__init__(
            namespace = 'timeline',
            monitor = monitor,
            child = self.box2,
            layer = 'overlay',
            style = 'background:rgba(128, 50, 50, 0);',
            anchor = ['right'],
            margin_right = 0
        )
        self.fixed = False
    
    def fix_hours (self):
        for h in self.hours:
            if h.get_allocation().height > 0:
                m = h.get_allocation().y
                m = self.vadjust(h, m)
                self.box2.move(h, 10, m)
                self.fixed = True

    def vadjust (self, elem, y):
        alloc = elem.get_allocation()
        return y - (alloc.height // 2) + 8
    
    def update_time (self, time, battery):

        iconsize = '1.5em'

        if time is None:
            now = datetime.now()
            time = now.hour * 3600 + now.minute * 60 + now.second

            if not self.fixed: self.fix_hours()
        top = self.h - (time / 86400.0 * self.h)
        # print('time shift', top, battery)
        self.box2.move(self.line_now, 0, self.vadjust(self.line_now, top))

        eta = battery[1] or 0
        if battery[0] == -1:
            start = self.h - top
            end = (start + (eta * 60 / 86400.0 * self.h)) % self.h
            self.battery_end.set_label("󰯆")
            self.battery_end.set_style(f"font-size: {iconsize};color:{gra(1)};")
            self.box2.move(self.battery_end, 0, self.vadjust(self.battery_end, self.h - end))
        elif battery[0] == 1:
            start = self.h - top
            end = (start + (eta * 60 / 86400.0 * self.h)) % self.h
            self.battery_end.set_label("󰂄")
            self.battery_end.set_style(f"font-size: {iconsize};color:{gra(0)};")
            self.box2.move(self.battery_end, 0, self.vadjust(self.battery_end, self.h - end))
        # self.set_style(f"background-image:linear-gradient(to top, transparent {start}px, {gra(0)} {start}px, {gra(1)} {end}px, transparent {end}px);")
        else:
            self.battery_end.set_label("")
        if battery[0]:
            self.line_now.set_style(f"font-size: 2em;color:{gra(battery[2])};text-shadow:0 0 1px black;")
        else:
            self.line_now.set_style(f"font-size: 2em;color:red;")